/*
 * File:   TESTEO.c
 * Author: Joseph
 *
 * Created on 14 de octubre de 2024, 09:39 AM
 */

//C�digo basado en gran medida del Ingeniero Kalun Lao, con modificaciones hechas para ser m�s compacto y ocupe menos espacio

#include <xc.h>
#include "cabecera.h"
#include <string.h>
#define _XTAL_FREQ 64000000UL

#define max7219_cs RB2
#define max7219_clk RB1
#define max7219_data RB0

#define DECODE_MODE  0x09
#define INTENSITY    0x0A
#define SCAN_LIMIT   0x0B
#define SHUTDOWN     0x0C
#define DISPLAY_TEST 0x0F
#define mode 0x00

unsigned char vacio[]={0b0000000,0b0000000,0b0000000,0b0000000,0b0000000,0b0000000,0b0000000}; // nada en absoluto
unsigned char num_0[]={0b0000000,0b0000000,0b0111110,0b1000001,0b1000001,0b0111110,0b0000000}; // 0
unsigned char num_1[]={0b0000000,0b0000000,0b1000010,0b1111111,0b1000000,0b0000000,0b0000000}; // 1
unsigned char num_2[]={0b0000000,0b0000000,0b1100010,0b1010001,0b1001001,0b1000110,0b0000000}; // 2
unsigned char num_3[]={0b0000000,0b0000000,0b0100010,0b1000001,0b1001001,0b0110110,0b0000000}; // 3
unsigned char num_4[]={0b0000000,0b0000000,0b0011000,0b0010100,0b0010010,0b1111111,0b0000000}; // 4
unsigned char num_5[]={0b0000000,0b0000000,0b0100111,0b1000101,0b1000101,0b0111001,0b0000000}; // 5
unsigned char num_6[]={0b0000000,0b0000000,0b0111110,0b1001001,0b1001001,0b0110000,0b0000000}; // 6
unsigned char num_7[]={0b0000000,0b0000000,0b1100001,0b0010001,0b0001001,0b0000111,0b0000000}; // 7
unsigned char num_8[]={0b0000000,0b0000000,0b0110110,0b1001001,0b1001001,0b0110110,0b0000000}; // 8
unsigned char num_9[]={0b0000000,0b0000000,0b0000110,0b1001001,0b1001001,0b0111110,0b0000000}; // 9
unsigned char numero=0;
unsigned char deco_centena[8];
unsigned char deco_decena[8];
unsigned char deco_unidad[8];


const unsigned char* numeros[] = {
    num_0, num_1, num_2, num_3, num_4,
    num_5, num_6, num_7, num_8, num_9
};

void decodificacion(unsigned char numero) {
    unsigned char centena = numero / 100;
    unsigned char decena = (numero % 100) / 10;
    unsigned char unidad = numero % 10;

    // Copiar los patrones correspondientes
    for(int i = 0; i < 8; i++) {
        deco_centena[i] = numeros[centena][i];
        deco_decena[i] = numeros[decena][i];
        deco_unidad[i] = numeros[unidad][i];
    }
}

void configuro(void){
    OSCCON1 = 0x60;
    OSCFRQ =0x08;
    OSCEN=0x40;
    TRISB= 0x00;
    ANSELB = 0x00;
}
void max7219_writedata(uint8_t comando, uint8_t dato) {
    max7219_cs=1;
    max7219_clk=0;
    max7219_data=0;
    max7219_cs=0;
    //envio del comando
    uint16_t var_x=(comando<<8)|dato;
    for (uint8_t i=0; i<16; i++){
        if(var_x&(0x8000>>i)){
            max7219_data=1;
        }
        else{
            max7219_data=0;
        }
        max7219_clk=1;
        max7219_clk=0;
    }
    max7219_cs=1;
    max7219_cs=0;
}
void inicializacion(void){
    configuro();
    max7219_writedata(DECODE_MODE, mode);  // Modo de decodificaci�n: sin decodificaci�n para d�gitos 7-0
    max7219_writedata(INTENSITY, 0x08);  // Intensidad: valor m�ximo (15/15)
    max7219_writedata(0x0B, 0x07);  // L�mite de escaneo: mostrar todos los d�gitos
    max7219_writedata(0x0C, 0x01);  // Apagado: modo normal de operaci�n
}

void max7219_clear(void)
    {
    for (uint8_t i=0; i<8; i++)
        {
        if (mode==0xFF)
            {max7219_writedata(i+1,0x0F);}
        else
            {max7219_writedata(i+1,0);}
        }
    }    

void max7219_columna(uint8_t columna) {
    if (columna < 1 || columna > 8) return;  // Verificaci�n de l�mites

    // Apagar todas las columnas primero
    for (uint8_t i = 1; i < 8; i++) {
        max7219_writedata(i,0x00 );
    }

    // Encender la columna especificada
    max7219_writedata(columna, 0xFF);
}
void spriteWrite(unsigned char *numero) {
    for (uint8_t i = 1; i <= 8; i++) {
        max7219_writedata(i, numero[i-1]);
    }
}
void max7219_scroll(unsigned char *numero, unsigned char cantidad) {
    static uint8_t m = 0;  
    uint8_t i;
    unsigned char z = 0;  // Offset para moverse entre patrones
    
    for(i = 1; i <= 8; i++) {
        max7219_writedata(i, numero[((i+m)%(8*cantidad)) + z]);
        __delay_ms(10);
    }
    
    z = z + 8;  // Avanza al siguiente patr�n
    m++;        // Avanza la posici�n de scroll
    
    // Reiniciar contadores cuando lleguen al l�mite
    if(m >= ((cantidad)*8)) m = 0;
    if(z >= ((cantidad)*8)) z = 0;
}
//auxilio
void main(void) {
    inicializacion();
    max7219_clear();    
    while(1) {
        unsigned char buffer[40];
        decodificacion(144);
        
        // Copiar manualmente
        strcpy(buffer, vacio);
        strcat(buffer, deco_centena);
        strcat(buffer, deco_decena);
        strcat(buffer, deco_unidad);
        strcat(buffer, vacio);
        max7219_scroll(buffer, 5);
    }
}